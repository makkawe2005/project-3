$(function() {
    describe('RSS Feeds', function() {
        it('are defined', function() {
            expect(allFeeds).toBeDefined();
            expect(allFeeds.length).toBeGreaterThan(0);
        });
        // A test that define each feed has a url ...
        it('each has url',function(){
            for(let feed of allFeeds){
                expect(feed.url).toBeDefined();
                expect(feed.url.constructor).toBe(String);
                expect(feed.url.length).not.toBe(0);
            }
        });
        // A test that define each feed object  has a name and name is not empty ...
        it('each has name',function(){
            for(let feed of allFeeds){
                expect(feed.name).toBeDefined();
                expect(feed.name.constructor).toBe(String);
                expect(feed.name.length).not.toBe(0);
            }
        });
    });
    //Write a new test suite named "The menu"
    describe('The menu',function(){
        //A test that ensures the menu element is hidden by default.
        it ('hidden by default', function(){
            let isHidden=document.body.classList.contains('menu-hidden');
            expect(isHidden).toBe(true);
        });
        //A test for the menu expectations display when clicked and does it hide when clicked again.
         it('toggles view when icon is clicked', function(){
             let menuIcon = document.querySelector('a.menu-icon-link');
             menuIcon.click();
             expect(document.body.classList.contains('menu-hidden')).toBe(false);
             menuIcon.click();
             expect(document.body.classList.contains('menu-hidden')).toBe(true);
         });
    });
    //Write a new test suite named "Initial Entries"
    describe('Initial Entries',function(){
        // A test that ensures when the loadFeed function is called and completes its work ... 
        beforeEach(function(done){
            loadFeed(1,done);
        });
        
        it('has entries in feed container',function(){
            let feedContainer = document.querySelector('div.feed');
            let entries = feedContainer.querySelectorAll('article.entry');
            expect(entries.length).toBeGreaterThan(0);
        });
    });
    // Write a new test suite named "New Feed Selection" 
    describe('New Feed Selection',function(){
       //TODO: Write a test that ensures when a new feed is loaded by the loadFeed function that the content actually changes.
        let initialFeed,newFeed;
        beforeEach(function(done){
            loadFeed(3,function(){
                initialFeed = document.querySelector('div.feed').innerHTML;
                loadFeed(2, function(){
                    newFeed = document.querySelector('div.feed').innerHTML;
                    done();
                });
            });
        }) ;

        it('loads new feeds', function(){
            expect(initialFeed).not.toBe(newFeed);
        });
    });
}());
