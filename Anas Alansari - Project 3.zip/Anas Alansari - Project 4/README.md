
## How to Run the Application

1-Find the index.html file, and open the file in a modern browser it may take some time to completely load as additional network requests are made.

2-Once loaded, The Jasmine test results should be displayed at the bottom of the index.html page.

3-Open the jasmine/spec/feedreader.js file to start editing the test suites.